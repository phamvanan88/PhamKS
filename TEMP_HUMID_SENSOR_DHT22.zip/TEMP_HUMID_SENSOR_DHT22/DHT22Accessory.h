#pragma once
//#include <HomeSpan.h>
#include <DHT.h>

// -------- DHT Sensor Configuration --------
#define DHTPIN 5
#define DHTTYPE DHT22
DHT dht(DHTPIN, DHTTYPE);

// -------- Shared Data DHT22 state --------
static float sharedTemp = 0;
static float sharedHumid = 0;

// -------- DHT Reading Function --------
void updateDHTReading() {
    unsigned long startTime = millis();

    float t = dht.readTemperature()-1;
    float h = dht.readHumidity()-6;

    if (!isnan(t) && !isnan(h)) {
      sharedTemp = t;
      sharedHumid = h;
      Serial.printf("🌡 Temp: %.1f°C | 💧 Humidity: %.1f%%\n", t, h);
    } else {
      Serial.println("❌ Failed to read from DHT22!");
    }
    unsigned long endTime = millis();
    Serial.print("DHT22 read time: ");
    Serial.print(endTime - startTime);
    Serial.println(" ms");
}

// -------- Temperature Service --------
struct DHT22Temperature : Service::TemperatureSensor {
  SpanCharacteristic *tempChar;
  DHT22Temperature() {
    tempChar = new Characteristic::CurrentTemperature(0.0);
  }
  void loop() override {
    tempChar->setVal(sharedTemp);
  }
};
// -------- Humidity Service --------
struct DHT22Humidity : Service::HumiditySensor {
  SpanCharacteristic *humidChar;
  DHT22Humidity() {
    humidChar = new Characteristic::CurrentRelativeHumidity(0.0);
  }
  void loop() override {
    humidChar->setVal(sharedHumid);
  }
};
