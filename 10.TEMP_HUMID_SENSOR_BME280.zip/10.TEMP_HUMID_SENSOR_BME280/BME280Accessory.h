#pragma once
//#include <HomeSpan.h>
#include <Wire.h> // is the I2C communication library on Arduino.
#include <Adafruit_BMP280.h> // library for BMP280 sensor

// -------- BME280 Sensor Setup --------
#define I2C_SDA 4
#define I2C_SCL 5
#define SEALEVELPRESSURE_HPA (1013.25)

Adafruit_BMP280 bmp;

// -------- Shared Data BME280 state --------
static float sharedTemp = 0;
static float sharedHumid = 0;
static float sharedPress = 0;
static bool bmeInitialized = false;

// -------- BME280 Reading Function each 5s --------
void updateBMEReading() {
    if (!bmeInitialized) {
      Serial.println("❌ Failed to connect to BME280!");
      return;
    }
    unsigned long startTime = millis();

    float t = bmp.readTemperature();
    float h = 0;//bme.readHumidity();
    float p = bmp.readPressure()/ 100.0F;//(fake humid in 0-100)  // convert Pa to hPa (/100.0F as default)
    float a = bmp.readAltitude(p);
    //float a = 44330.0 * (1.0 - pow(p/ 1013.25, 0.1903));

    if (!isnan(t) && !isnan(p)) {
      sharedTemp = t;
      sharedHumid = p/100.0F;
      Serial.printf("🌡 Temp: %.1f°C | 💧 Humidity: %.1f%% | 📈 Pressure: %.1f hPa | 🏔 Altitude: %.1f m\n",
                t, h, p, a);
    } else {
      Serial.println("❌ Failed to read from BME280!");
    }
    unsigned long endTime = millis();
    Serial.print("BME280 read time: ");
    Serial.print(endTime - startTime);
    Serial.println(" ms");
}

// -------- Temperature Service - update Temp value to Apple homekit --------
struct BME280Temperature : Service::TemperatureSensor {
  SpanCharacteristic *tempChar;
  BME280Temperature() {
    tempChar = new Characteristic::CurrentTemperature(0.0);
  }
  void loop() override {
    tempChar->setVal(sharedTemp);
  }
};
// -------- Humidity Service -update Humid value to Apple homekit --------
struct BME280Humidity : Service::HumiditySensor {
  SpanCharacteristic *humidChar;
  BME280Humidity() {
    humidChar = new Characteristic::CurrentRelativeHumidity(0.0);
  }
  void loop() override {
    humidChar->setVal(sharedHumid);
  }
};
